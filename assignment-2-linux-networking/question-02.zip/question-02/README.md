# Web App Deployment – Netlify Demo

This folder contains a sample welcome page and deployment instructions for Question 2 of the Celebal DevOps Internship Assignment.

Includes:
- index.html
- steps.md
