# Assignment 2 – Question 2

## 🔧 Original Task:
Create an App Service Plan, provision a Web App in the existing App Service Plan, and deploy a simple welcome page on it.

---

## ✅ Updated Execution (Using Netlify)

Due to unavailability of Azure (university Microsoft account blocked by MFA policy), this task is demonstrated using **Netlify Free Hosting**.

---

### 🧪 Steps Performed:

1. Created a folder with `index.html` welcome page
2. Zipped the folder manually
3. Logged into [Netlify](https://app.netlify.com)
4. Used **manual deploy (drag-and-drop)** option
5. Successfully deployed and received a public URL

---

### 🌐 Live URL:
👉 *Will be added after Netlify deployment*

---

### 🧾 Notes:
This simulates real-world Azure App Service deployment using a free equivalent platform, ideal for DevOps testing and demonstration.


